INGInious' documentation
========================

.. toctree::
    :maxdepth: 2

    install_documentation
    commands
    teacher_documentation
    developer_documentation


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

