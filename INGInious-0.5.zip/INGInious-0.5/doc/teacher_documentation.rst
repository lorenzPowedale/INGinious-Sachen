Teacher's documentation
=======================

Contents:

.. toctree::
   :maxdepth: 2

   teacher_doc/what_is_inginious
   teacher_doc/create_course
   teacher_doc/create_task
   teacher_doc/translating
   teacher_doc/create_container
   teacher_doc/course_admin
   teacher_doc/lti
