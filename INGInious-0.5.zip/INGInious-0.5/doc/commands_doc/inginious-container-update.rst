inginious-containers-update
===========================

Update all the containers created and/or maintained by the INGInious team.

.. program:: inginious-container-update

Takes no argument, but needs a properly configured Docker environment. If you use a remote Docker instance, please
check the ``DOCKER_HOST`` environment variable.