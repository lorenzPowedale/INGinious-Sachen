.. _task:

Creating a new task
===================

.. toctree::
   :maxdepth: 2

   task_tuto
   run_file
   task_file
   share_files
   common
   random
   system_files
   testing
   best_practices