Installation, configuration and upgrade
=======================================

.. toctree::
    :maxdepth: 2

    install_doc/installation
    install_doc/updating
    install_doc/config_reference
    install_doc/troubleshooting
