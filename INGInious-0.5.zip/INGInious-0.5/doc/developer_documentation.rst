Developer's documentation
=========================

.. toctree::
   :maxdepth: 2

   dev_doc/understand_inginious
   dev_doc/plugins
   dev_doc/how_to_extend

Code documentation
------------------

.. toctree::
   :maxdepth: 3

   api_doc/inginious