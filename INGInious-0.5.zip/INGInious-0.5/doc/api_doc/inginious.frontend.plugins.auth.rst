inginious.frontend.plugins.auth package
==============================================

.. automodule:: inginious.frontend.plugins.auth
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.frontend.plugins.auth.db_auth module
-----------------------------------------------------

.. automodule:: inginious.frontend.plugins.auth.db_auth
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.plugins.auth.demo_auth module
-------------------------------------------------------

.. automodule:: inginious.frontend.plugins.auth.demo_auth
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.plugins.auth.ldap_auth module
-------------------------------------------------------

.. automodule:: inginious.frontend.plugins.auth.ldap_auth
    :members:
    :undoc-members:
    :show-inheritance:


