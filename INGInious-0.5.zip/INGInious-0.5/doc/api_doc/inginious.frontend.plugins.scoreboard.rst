inginious.frontend.plugins.scoreboard package
====================================================

.. automodule:: inginious.frontend.plugins.scoreboard
    :members:
    :undoc-members:
    :show-inheritance:

