inginious.frontend.plugins.contests package
==================================================

.. automodule:: inginious.frontend.plugins.contests
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.frontend.plugins.contests.contests module
----------------------------------------------------------

.. automodule:: inginious.frontend.plugins.contests.contests
    :members:
    :undoc-members:
    :show-inheritance:


