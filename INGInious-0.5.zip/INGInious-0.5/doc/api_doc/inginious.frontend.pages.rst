inginious.frontend.pages package
=======================================

.. automodule:: inginious.frontend.pages
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    inginious.frontend.pages.api
    inginious.frontend.pages.course_admin

Submodules
----------

inginious.frontend.pages.aggregation module
--------------------------------------------------

.. automodule:: inginious.frontend.pages.aggregation
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.course module
---------------------------------------------

.. automodule:: inginious.frontend.pages.course
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.index module
--------------------------------------------

.. automodule:: inginious.frontend.pages.index
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.maintenance module
--------------------------------------------------

.. automodule:: inginious.frontend.pages.maintenance
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.tasks module
--------------------------------------------

.. automodule:: inginious.frontend.pages.tasks
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.utils module
--------------------------------------------

.. automodule:: inginious.frontend.pages.utils
    :members:
    :undoc-members:
    :show-inheritance:


