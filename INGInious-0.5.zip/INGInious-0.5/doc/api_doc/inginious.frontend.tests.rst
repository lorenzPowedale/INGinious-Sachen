inginious.frontend.tests package
=======================================

.. automodule:: inginious.frontend.tests
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------


inginious.frontend.tests.SeleniumTest module
---------------------------------------------------

.. automodule:: inginious.frontend.tests.SeleniumTest
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.tests.TestLogin module
------------------------------------------------

.. automodule:: inginious.frontend.tests.TestLogin
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.tests.TestParsableText module
-------------------------------------------------------

.. automodule:: inginious.frontend.tests.TestParsableText
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.tests.TestTaskDisplay module
------------------------------------------------------

.. automodule:: inginious.frontend.tests.TestTaskDisplay
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.tests.TestTaskSubmission module
---------------------------------------------------------

.. automodule:: inginious.frontend.tests.TestTaskSubmission
    :members:
    :undoc-members:
    :show-inheritance:


