inginious.frontend.pages.api package
===========================================

.. automodule:: inginious.frontend.pages.api
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.frontend.pages.api.auth_methods module
-------------------------------------------------------

.. automodule:: inginious.frontend.pages.api.auth_methods
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.api.authentication module
---------------------------------------------------------

.. automodule:: inginious.frontend.pages.api.authentication
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.api.courses module
--------------------------------------------------

.. automodule:: inginious.frontend.pages.api.courses
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.api.submissions module
------------------------------------------------------

.. automodule:: inginious.frontend.pages.api.submissions
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.api.tasks module
------------------------------------------------

.. automodule:: inginious.frontend.pages.api.tasks
    :members:
    :undoc-members:
    :show-inheritance:


