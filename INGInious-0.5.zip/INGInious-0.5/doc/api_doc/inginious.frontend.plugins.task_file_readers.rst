inginious.frontend.plugins.task_file_readers package
===========================================================

.. automodule:: inginious.frontend.plugins.task_file_readers
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.frontend.plugins.task_file_readers.json_reader module
----------------------------------------------------------------------

.. automodule:: inginious.frontend.plugins.task_file_readers.json_reader
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.plugins.task_file_readers.rst_reader module
---------------------------------------------------------------------

.. automodule:: inginious.frontend.plugins.task_file_readers.rst_reader
    :members:
    :undoc-members:
    :show-inheritance:


