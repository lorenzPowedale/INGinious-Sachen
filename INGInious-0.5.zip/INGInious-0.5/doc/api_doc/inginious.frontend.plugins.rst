inginious.frontend.plugins package
=========================================

.. automodule:: inginious.frontend.plugins
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    inginious.frontend.plugins.auth
    inginious.frontend.plugins.contests
    inginious.frontend.plugins.scoreboard
    inginious.frontend.plugins.task_file_readers

Submodules
----------

inginious.frontend.plugins.client_test module
----------------------------------------------------

.. automodule:: inginious.frontend.plugins.client_test
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.plugins.demo_page module
--------------------------------------------------

.. automodule:: inginious.frontend.plugins.demo_page
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.plugins.edx module
--------------------------------------------

.. automodule:: inginious.frontend.plugins.edx
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.plugins.git_repo module
-------------------------------------------------

.. automodule:: inginious.frontend.plugins.git_repo
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.plugins.simple_grader module
------------------------------------------------------

.. automodule:: inginious.frontend.plugins.simple_grader
    :members:
    :undoc-members:
    :show-inheritance:


