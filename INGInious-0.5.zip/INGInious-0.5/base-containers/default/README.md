INGInious
=========

This container is part of [INGInious](https://github.com/UCL-INGI/INGInious), an intelligent grader that allows secured and automated testing of code made by students. 

Default container (ingi/inginious-c-default)
--------------------------------------------

The default container image.

It can execute tasks written in shell, bash, or python (2 and 3).
